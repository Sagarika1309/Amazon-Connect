  
export const AGENT_CCP_URL = 'https://<YOUR AMAZON CONNECT INSTANCE ALIAS>.awsapps.com/connect/ccp-v2/chat';

export const AWS_REGION = 'us-east-1';

// Check the invokeURL under the ChimeConnectIntegrationDemo CF template output tab
export const INVOKE_URL = '<OUTPUT APIGATEWAY INVOKE URL>';

// Check the ChimeConnectDemoUserAccessKey under the ChimeConnectIntegrationDemo CF template output tab
export const ACCESS_KEY = '<CHIME CONNECT DEMO USER ACCESS KEY>';

// Check the ChimeConnectDemoUserSecretKey under the ChimeConnectIntegrationDemo CF template output tab 
export const SECRET_KEY = '<CHIME CONNECT DEMO USER SECRET KEY>';
