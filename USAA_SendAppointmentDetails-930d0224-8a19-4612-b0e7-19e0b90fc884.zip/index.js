var AWS = require("aws-sdk");
var pinpoint = new AWS.Pinpoint();

//main entry 
exports.handler = (event, context, callback) => {
    console.log("Incoming Event: " + JSON.stringify(event));

    //You must have these attributes set in your Contact Flow prior to invoking lambda function
    //var destinationNumber = event.Details.Parameters.destinationNumber;
    var destinationNumber = event.Details.ContactData.Attributes.destinationNumber
    var destinationNumber2 = event.Details.Parameters.destinationNumber
    if(destinationNumber == null)
    destinationNumber = destinationNumber2
    else
    destinationNumber = destinationNumber
    var messageContent = event.Details.Parameters.messageContent;

    var params = {
        //ApplicationId must match the ID of the application you created in AWS Mobile Hub
        ApplicationId: "1c6d945d0dba4ee2ab753cc19e2c9fd5",
        MessageRequest: {
            Addresses: {
                [destinationNumber]: {
                    ChannelType: "SMS",
                },
            },
            MessageConfiguration: {
                SMSMessage: {
                    Body: messageContent,
                    MessageType: "TRANSACTIONAL",
                    SenderId: "AWS",
                }
            },
        }
    };

    // Send the SMS
    pinpoint.sendMessages(params, function(err, data) {
        if (err) {
            console.log(err);
            context.fail(buildResponse(false));
        } else {
            console.log("Great Success");
            callback(null, buildResponse(true, "none"));
        }
    });
};

// Return Result to Connect
function buildResponse(isSuccess) {
    if (isSuccess) {
        return {
            lambdaResult: "Success"
        };
    } else {
        return {
            lambdaResult: "Error"
        };
    }
}