import json
import boto3
import random
import math



TABLE_NAME = "bupa_customer"

# Creating the DynamoDB Client
dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")

# Creating the DynamoDB Table Resource
dynamodb = boto3.resource('dynamodb', region_name="us-east-1")

def lambda_handler(event, context):
  table = dynamodb.Table(TABLE_NAME)
  phoneNumber = event['Details']['Parameters']['phoneNumber']
  if not phoneNumber.startswith('+'):
    phoneNumber = "+"+phoneNumber
  data = table.get_item (
    Key={
        'phoneNumber': phoneNumber
      }
    )

  customerdata = json.dumps(data)
  if 'Item' in data:
    resultmap = data['Item']
    print (resultmap)
    #authCodeFromDb = resultmap['authCode']
    #print("Code from db", authCodeFromDb)
    
    #if resultmap.has_key('authCode'):
    if 'authCode' in resultmap:
      resultmap = {'authCode': resultmap['authCode'] }
    else:
      authCode =  generateAuthCode()
      resultmap = {'authCode': authCode}
      update_customer_auth_code(phoneNumber, authCode)
      
  else:
    resultmap = {'authCode': 'Null'}
  
  
  return resultmap
  
  
def generateAuthCode():
  print("Hello from a function")
  ## storing strings in a list
  digits = [i for i in range(0, 10)]

  ## initializing a string
  random_str = ""
  
  ## we can generate any lenght of string we want
  for i in range(6):
  ## generating a random index
  ## if we multiply with 10 it will generate a number between 0 and 10 not including 10
  ## multiply the random.random() with length of your base list or str
    index = math.floor(random.random() * 10)
    
    random_str += str(digits[index])
  
  ## displaying the random string
  print(random_str)
  return random_str
    

def update_customer_auth_code(phoneNumber, authCode, dynamodb=None):
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb', region_name="us-east-1")

    table = dynamodb.Table(TABLE_NAME)

    response = table.update_item(
        Key={
            'phoneNumber': phoneNumber
        },
        UpdateExpression="set authCode=:ac",
        ExpressionAttributeValues={
            ':ac': authCode
        },
        ReturnValues="UPDATED_NEW"
    )
    return response
